package com.niit.ShoppingCart;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController 
{
	
	@RequestMapping("/")
	public String gotoindex()
	{
	  return "index";
    }
	
	@RequestMapping("/login")
	public String login(Model model)
	{
		model.addAttribute("userClickedlogin","true");
	   return "login";
    }
	@RequestMapping("/register")
	public String register(Model model)
	{
       model.addAttribute("userClickedregister","true");
	   return "register";
    }
	
	
	
	@RequestMapping("/validate")
	public String gotovalidate(@RequestParam(name="user id")String userID,@RequestParam(name="password")String password, Model model )
 {
		if(userID.equals("kokila")&& password.equals("1234"))
	{
		model.addAttribute("success","your successfully loggedin");
		return"login";
	}
	   else
	{
		 model.addAttribute("unscuccesful","invalid creditential.please try again");
	}
		
       return"login";
 }
	
}


